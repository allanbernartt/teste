const path = require('path')

const rootDir = path.dirname(require.main.filename)

module.exports = rootDir