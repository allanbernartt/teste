const path = require('path')
const fs = require('fs')
const express = require('express')
const rootDir = require('./utils/rootdir')
const fileupload = require("express-fileupload");
const _ = require('lodash');
const https = require('https')

const port  = process.env.port || 4001
const app = express()
app.use(express.urlencoded({ extended: true }))
app.use(express.json())
app.use(express.static(path.join(rootDir, 'public')))
app.use(fileupload());

app.set('view engine', 'ejs')

app.get('/', (req, res) => {
    res.sendFile('index.html')
})

app.post('/', async (req, res) => {
    const url = req.body.url

    const result = await get_page(url)
    await create_text(result)
    await add_css()

    res.redirect('index.html')
})

async function add_css() {
    return new Promise((resolve) => {
        let include = '<?php include "xxx.php"; ?>'
        let data = fs.readFileSync('public/myfile.txt').toString().split("\n");
        data.splice(2588, 0, include);
        let text = data.join("\n");

        fs.writeFile('public/newfile.html', text, function (err) {
            if (err) return console.log(err);
        });
        resolve()
    })
}

async function create_text(result) {
    return new Promise((resolve) => {
        fs.writeFile('public/myfile.txt', result, err => {
            if (err) {
                console.error(err);
            }
            resolve()
           
        });
    })
}

async function get_page(url) {


    return new Promise((resolve) => {
        let data = ''

        https.get(url, res => {

            res.on('data', chunk => { data += chunk })

            res.on('end', () => {

                resolve(data);

            })
        })
    })
}

// usar este para rodar localmente
/* app.listen(port, (req, res) => {
    console.log('Server Running on port 4001')
})
 */

//usar este para rodar no servidor
app.listen()